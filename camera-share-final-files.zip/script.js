import { initializeApp } from
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-app.js";

import {
  getDatabase,
  ref,
  set,
  get,
  onValue,
  onChildAdded,
  push
} from
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-database.js";

import {
  getAuth,
  signInAnonymously
} from
  "https://www.gstatic.com/firebasejs/12.1.0/firebase-auth.js";

// =============================
// FIREBASE CONFIG
// =============================

const firebaseConfig = {
  apiKey: "AIzaSyD5kH_VWXI2r_znQbhlHenqDEZBJmnJcFM",
  authDomain: "camra-share.firebaseapp.com",
  databaseURL: "https://camra-share-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "camra-share",
  storageBucket: "camra-share.firebasestorage.app",
  messagingSenderId: "618409884143",
  appId: "1:618409884143:web:d787884065b651f54f9e1a",
  measurementId: "G-ZLF7B4GFR4"
};

const app = initializeApp(firebaseConfig);
const db = getDatabase(app);
const auth = getAuth(app);

await signInAnonymously(auth);

// =============================
// DOM
// =============================

const home = document.getElementById("home");
const guest = document.getElementById("guest");
const host = document.getElementById("host");
const errorBox = document.getElementById("errorBox");
const errorText = document.getElementById("errorText");

const createBtn = document.getElementById("createBtn");
const shareBtn = document.getElementById("shareBtn");
const copyBtn = document.getElementById("copyBtn");

const status = document.getElementById("status");
const hostStatus = document.getElementById("hostStatus");

const localVideo = document.getElementById("localVideo");
const remoteVideo = document.getElementById("remoteVideo");
const localWrap = document.getElementById("localWrap");
const remotePlaceholder = document.getElementById("remotePlaceholder");

const inviteBox = document.getElementById("inviteBox");
const inviteLink = document.getElementById("inviteLink");

// =============================
// WEBRTC
// =============================

let peerConnection = null;
let localStream = null;
let roomId = null;
let remoteCandidateQueue = [];
let remoteDescriptionReady = false;

const rtcConfig = {
  iceServers: [
    { urls: "stun:stun.l.google.com:19302" },
    { urls: "stun:stun1.l.google.com:19302" }
  ]
};

function newPeerConnection() {
  return new RTCPeerConnection(rtcConfig);
}

function generateRoomId() {
  if (crypto.randomUUID) {
    return crypto.randomUUID().replaceAll("-", "").slice(0, 12);
  }
  return Math.random().toString(36).slice(2, 14);
}

function showOnly(section) {
  home.classList.add("hidden");
  guest.classList.add("hidden");
  host.classList.add("hidden");
  section.classList.remove("hidden");
}

function showError(message) {
  errorText.textContent = message;
  errorBox.classList.remove("hidden");
}

async function addRemoteCandidate(candidate) {
  if (!peerConnection || !candidate) return;

  const ice = new RTCIceCandidate(candidate);

  if (!remoteDescriptionReady) {
    remoteCandidateQueue.push(ice);
    return;
  }

  try {
    await peerConnection.addIceCandidate(ice);
  } catch (err) {
    console.warn("ICE candidate error:", err);
  }
}

async function flushRemoteCandidates() {
  if (!peerConnection) return;

  for (const candidate of remoteCandidateQueue) {
    try {
      await peerConnection.addIceCandidate(candidate);
    } catch (err) {
      console.warn("Queued ICE candidate error:", err);
    }
  }

  remoteCandidateQueue = [];
}

// =============================
// HOST
// =============================

createBtn.addEventListener("click", async () => {
  createBtn.disabled = true;
  errorBox.classList.add("hidden");

  try {
    roomId = generateRoomId();
    showOnly(host);

    hostStatus.textContent = "🔄 Room बनाया जा रहा है...";

    peerConnection = newPeerConnection();

    // Host NEVER requests its own camera.
    // It only receives guest video.
    peerConnection.addTransceiver("video", {
      direction: "recvonly"
    });

    peerConnection.ontrack = (event) => {
      const stream = event.streams?.[0];

      if (stream) {
        remoteVideo.srcObject = stream;
        remotePlaceholder.classList.add("hidden");
        hostStatus.textContent =
          "🟢 Guest का live camera connected है।";
      }
    };

    peerConnection.onconnectionstatechange = () => {
      const state = peerConnection.connectionState;
      console.log("Host connection state:", state);

      if (state === "connected") {
        hostStatus.textContent =
          "🟢 Guest का live camera दिखाई दे रहा है।";
      } else if (state === "connecting") {
        hostStatus.textContent =
          "🔄 Guest camera से connection हो रहा है...";
      } else if (state === "disconnected") {
        hostStatus.textContent =
          "⚠️ Connection temporarily disconnected.";
      } else if (state === "failed") {
        hostStatus.textContent =
          "❌ WebRTC connection failed. दोनों devices पर internet check करें।";
      }
    };

    peerConnection.oniceconnectionstatechange = () => {
      console.log(
        "Host ICE state:",
        peerConnection.iceConnectionState
      );
    };

    peerConnection.onicecandidate = async (event) => {
      if (!event.candidate) return;

      const candidateRef = push(
        ref(db, `rooms/${roomId}/hostCandidates`)
      );

      await set(candidateRef, event.candidate.toJSON());
    };

    // Create offer after recvonly transceiver exists.
    const offer = await peerConnection.createOffer();
    await peerConnection.setLocalDescription(offer);

    await set(ref(db, `rooms/${roomId}/offer`), {
      type: offer.type,
      sdp: offer.sdp
    });

    const url = new URL(window.location.href);
    url.search = "";
    url.searchParams.set("room", roomId);

    inviteLink.value = url.toString();
    inviteBox.classList.remove("hidden");

    hostStatus.textContent =
      "🟡 Guest को link भेजें और उसके Share Camera दबाने का इंतजार करें।";

    copyBtn.onclick = async () => {
      try {
        await navigator.clipboard.writeText(inviteLink.value);
        copyBtn.textContent = "✅ Copied";
        setTimeout(() => {
          copyBtn.textContent = "Copy";
        }, 2000);
      } catch {
        inviteLink.select();
        document.execCommand("copy");
        copyBtn.textContent = "✅ Copied";
      }
    };

    // Wait for guest answer.
    onValue(ref(db, `rooms/${roomId}/answer`), async (snapshot) => {
      const answer = snapshot.val();
      if (!answer || peerConnection.currentRemoteDescription) return;

      try {
        await peerConnection.setRemoteDescription(
          new RTCSessionDescription(answer)
        );

        remoteDescriptionReady = true;
        await flushRemoteCandidates();

        hostStatus.textContent =
          "🔄 Guest camera connection स्थापित हो रही है...";
      } catch (err) {
        console.error("Answer error:", err);
        hostStatus.textContent =
          "❌ Guest answer स्वीकार नहीं हुआ।";
      }
    });

    // Listen continuously so late ICE candidates are also received.
    onChildAdded(
      ref(db, `rooms/${roomId}/guestCandidates`),
      async (snapshot) => {
        await addRemoteCandidate(snapshot.val());
      }
    );

  } catch (err) {
    console.error(err);
    createBtn.disabled = false;
    showError("Room बनाने में समस्या हुई। Page refresh करके फिर कोशिश करें।");
  }
});

// =============================
// GUEST
// =============================

const params = new URLSearchParams(window.location.search);
const guestRoomId = params.get("room");

if (guestRoomId) {
  roomId = guestRoomId;
  showOnly(guest);

  shareBtn.addEventListener("click", async () => {
    shareBtn.disabled = true;
    errorBox.classList.add("hidden");

    try {
      status.textContent =
        "📷 Camera permission माँगी जा रही है...";

      // IMPORTANT:
      // Camera access occurs ONLY because the user clicked the button.
      localStream = await navigator.mediaDevices.getUserMedia({
        video: {
          facingMode: "environment",
          width: { ideal: 1280 },
          height: { ideal: 720 }
        },
        audio: false
      });

      localVideo.srcObject = localStream;
      localWrap.classList.remove("hidden");

      status.textContent =
        "✅ Camera permission मिल गई। Room से connection हो रहा है...";

      // Check room before continuing.
      const roomSnapshot = await get(
        ref(db, `rooms/${roomId}`)
      );

      if (!roomSnapshot.exists()) {
        stopLocalCamera();
        shareBtn.disabled = false;
        status.textContent = "❌ यह room मौजूद नहीं है।";
        return;
      }

      peerConnection = newPeerConnection();

      peerConnection.onconnectionstatechange = () => {
        const state = peerConnection.connectionState;
        console.log("Guest connection state:", state);

        if (state === "connected") {
          status.textContent =
            "🟢 आपका camera दूसरे व्यक्ति को live दिखाई दे रहा है।";
        } else if (state === "connecting") {
          status.textContent =
            "🔄 Live camera connection हो रही है...";
        } else if (state === "failed") {
          status.textContent =
            "❌ Connection failed. Internet connection check करें।";
          shareBtn.disabled = false;
        } else if (state === "disconnected") {
          status.textContent =
            "⚠️ Camera connection disconnected.";
        }
      };

      peerConnection.oniceconnectionstatechange = () => {
        console.log(
          "Guest ICE state:",
          peerConnection.iceConnectionState
        );
      };

      // Add user's camera tracks.
      for (const track of localStream.getTracks()) {
        peerConnection.addTrack(track, localStream);
      }

      peerConnection.onicecandidate = async (event) => {
        if (!event.candidate) return;

        const candidateRef = push(
          ref(db, `rooms/${roomId}/guestCandidates`)
        );

        await set(candidateRef, event.candidate.toJSON());
      };

      // Get host offer.
      const offerSnapshot = await get(
        ref(db, `rooms/${roomId}/offer`)
      );

      if (!offerSnapshot.exists()) {
        stopLocalCamera();
        shareBtn.disabled = false;
        status.textContent = "❌ Room का offer नहीं मिला।";
        return;
      }

      const offer = offerSnapshot.val();

      await peerConnection.setRemoteDescription(
        new RTCSessionDescription(offer)
      );

      remoteDescriptionReady = true;
      await flushRemoteCandidates();

      // Create answer.
      const answer = await peerConnection.createAnswer();

      await peerConnection.setLocalDescription(answer);

      await set(ref(db, `rooms/${roomId}/answer`), {
        type: answer.type,
        sdp: answer.sdp
      });

      // Receive host ICE candidates continuously.
      onChildAdded(
        ref(db, `rooms/${roomId}/hostCandidates`),
        async (snapshot) => {
          await addRemoteCandidate(snapshot.val());
        }
      );

    } catch (err) {
      console.error("Camera/WebRTC error:", err);

      shareBtn.disabled = false;

      if (err.name === "NotAllowedError") {
        status.textContent =
          "🚫 Camera permission denied. Camera शुरू नहीं किया गया।";
      } else if (err.name === "NotFoundError") {
        status.textContent =
          "❌ इस device पर camera नहीं मिला।";
      } else if (err.name === "SecurityError") {
        status.textContent =
          "❌ Browser security ने camera access रोक दिया। HTTPS/GitHub Pages इस्तेमाल करें।";
      } else {
        status.textContent =
          `❌ Camera/connection error: ${err.message || err.name}`;
      }
    }
  });
}

// =============================
// STOP CAMERA WHEN PAGE CLOSES
// =============================

function stopLocalCamera() {
  if (!localStream) return;

  for (const track of localStream.getTracks()) {
    track.stop();
  }

  localStream = null;
  localVideo.srcObject = null;
  localWrap.classList.add("hidden");
}

window.addEventListener("pagehide", () => {
  stopLocalCamera();

  if (peerConnection) {
    peerConnection.close();
    peerConnection = null;
  }
});
